#' A character string containing the version of `irace` including git SHA.
#' @export
irace_version <- '4.2.0.b50b134'
