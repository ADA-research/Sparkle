AUTHORS = 'Marius Lindauer'
VERSION = '2.0.0'
