#ifndef _DCCASAT2014_H
#define _DCCASAT2014_H

#include "basic.h"
#include "DCCASat2014_help.h"

#define sigscore	ave_weight   //significant score needed for aspiration

int		ave_weight=1;
int		delta_total_weight=0;

/**************************************** clause weighting for 3sat **************************************************/

int		threshold;
float		p_scale=0.3;//w=w*p+ave*(1-p)
float		q_scale=0.7;//q=1-p 
int		scale_ave;//scale_ave==ave_weight*q_scale

void smooth_clause_weights_3sat()
{
	int i,j,c,v;
	int new_total_weight=0;

	for (v=1; v<=num_vars; ++v) 
		score[v] = 0;
	
	//smooth clause score and update score of variables
	for (c = 0; c<num_clauses; ++c)
	{
		clause_weight[c] = clause_weight[c]*p_scale+scale_ave;
		
		new_total_weight+=clause_weight[c];
		
		//update score of variables in this clause 
		if (sat_count[c]==0) 
		{
			for(j=0; j<clause_lit_count[c]; ++j)
			{
				score[clause_lit[c][j].var_num] += clause_weight[c];
			}
		}
		else  if(sat_count[c]==1)
			score[sat_var[c]]-=clause_weight[c];
	}
	
	ave_weight=new_total_weight/num_clauses;
}

void update_clause_weights_3sat()
{
	int i,v;

	for(i=0; i < unsat_stack_fill_pointer; ++i)
		clause_weight[unsat_stack[i]]++;
	
	for(i=0; i<unsatvar_stack_fill_pointer; ++i)
	{
		v = unsatvar_stack[i];
		score[v] += unsat_app_count[v];
		if(score[v]>0 &&  conf_change[v]==1 && already_in_goodvar_stack[v] ==0)
		{
			push(v,goodvar_stack);
			already_in_goodvar_stack[v] =1;
		}
	}
	
	delta_total_weight+=unsat_stack_fill_pointer;
	if(delta_total_weight>=num_clauses)
	{
		ave_weight+=1;
		delta_total_weight -= num_clauses;
		
		//smooth weights
		if(ave_weight>threshold)
			smooth_clause_weights_3sat();
	}
}




/**********************************clause weighting for large ksat, k>3*************************************************/
const int	  dec_weight =1;
float  smooth_probability;
float  smooth_probability2;
int    large_clause_count_threshold;

//for PAWS (for large ksat)
int            large_weight_clauses[MAX_CLAUSES];
int            large_weight_clauses_count=0;	


void inc_clause_weights_large_sat()
{
	int i, j, c, v;
	
	for(i=0; i < unsat_stack_fill_pointer; ++i)
	{
		c = unsat_stack[i];
		clause_weight[c]++;
		if(clause_weight[c] == 2)
		{
			large_weight_clauses[large_weight_clauses_count++] = c;
		}
	}
	
	for(i=0; i<unsatvar_stack_fill_pointer; ++i)
	{
		v = unsatvar_stack[i];
		score[v] += unsat_app_count[v];
		if(score[v]>0 &&  conf_change[v]>0  && already_in_goodvar_stack[v] ==0)//
		{
			push(v,goodvar_stack);
			already_in_goodvar_stack[v] =1;
		}
	}

}

void smooth_clause_weights_large_sat()
{
	int i, j,clause, var;
	for(i=0; i<large_weight_clauses_count; i++)
	{
		clause = large_weight_clauses[i];
		if(sat_count[clause]>0)
		{
			clause_weight[clause]-=dec_weight;
				
			if(clause_weight[clause]==1)
			{
				large_weight_clauses[i] = large_weight_clauses[--large_weight_clauses_count];
				i--;
			}
			if(sat_count[clause] == 1)
			{
				var = sat_var[clause];
				score[var]+=dec_weight;
				if(score[var]>0 &&  conf_change[var]>0  && already_in_goodvar_stack[var]==0)
				{
					push(var,goodvar_stack);
					already_in_goodvar_stack[var]=1;
				}
			}
		}
	}
	
}

void update_clause_weights_large_sat()
{
	if( ((rand()%MY_RAND_MAX_INT)*BASIC_SCALE)<smooth_probability && large_weight_clauses_count>large_clause_count_threshold )
		smooth_clause_weights_large_sat();
	else 
		inc_clause_weights_large_sat();
}

/**************************setting clause weighting scheme*********************************************************/

void set_clause_weighting()
{	
	if(probtype==SAT3)
	{
		update_clause_weights = update_clause_weights_3sat;
		threshold=200+(num_vars+250)/500;
		scale_ave=(threshold+1)*q_scale;//when smoothing, ave_weight=threshold+1.
	}
	else if(probtype==SAT4)
	{
		update_clause_weights = update_clause_weights_large_sat;
		smooth_probability = 0.75;
		large_clause_count_threshold = 10;
	}
	else if(probtype==SAT5)
	{
		update_clause_weights = update_clause_weights_large_sat;
		smooth_probability = 0.8;
		//if(num_vars>=1500) smooth_probability = 0.725;
		large_clause_count_threshold = 10;
	}
	else if(probtype==SAT6)
	{
		update_clause_weights = update_clause_weights_large_sat;
		smooth_probability = 0.9;
		large_clause_count_threshold = 10;
	}
	else if(probtype==SAT7)
	{
		update_clause_weights = update_clause_weights_large_sat;
		smooth_probability = 0.92;
		large_clause_count_threshold = 10;
	}
	else //non k-SAT
	{
		update_clause_weights = update_clause_weights_3sat;
		threshold=300;
		scale_ave=(threshold+1)*q_scale;
	}
}

/****************/
int Gamma = 1000;
int Beta = 1000;
int para_d = 6;
/****************/

//int delta_age;

int pick_var_large_DCCASat2014()
{
	int         i,k,c,v;
	int         best_var;
	lit*		clause_c;
	
	int hscore_v;
	int hscore_best_var;
	
	/**Greedy Mode**/
	
	/*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
	if(goodvar_stack_fill_pointer>0)
	{
	
		best_var = -1;
		for(i=0; i<goodvar_stack_fill_pointer; i++)
		{
			v = goodvar_stack[i];
			if(cscc[v]==1)
			{
				best_var = v;
				break;
			}
		}
		
		if(best_var!=-1)
		{
			for(i++; i<goodvar_stack_fill_pointer; i++)
			{
				v = goodvar_stack[i];
				if(cscc[v]==0)
					continue;
				if(score[v]>score[best_var])
					best_var = v;
				else if(score[v]==score[best_var])
				{
					if(pscore[v]+(step-time_stamp[v])/Gamma > pscore[best_var]+(step-time_stamp[best_var])/Gamma)
						best_var = v;
					else if(pscore[v]+(step-time_stamp[v])/Gamma < pscore[best_var]+(step-time_stamp[best_var])/Gamma)
						continue;
					else if(time_stamp[v]<time_stamp[best_var])
						best_var = v;
				}
			}
			
			return best_var;
		}
	
		best_var = goodvar_stack[0];
		
		for(i=1; i<goodvar_stack_fill_pointer; ++i)
		{
			v=goodvar_stack[i];
			if(score[v]>score[best_var]) best_var = v;
	
			else if(score[v]==score[best_var])
			{
				if(pscore[v]+(step-time_stamp[v])/Gamma > pscore[best_var]+(step-time_stamp[best_var])/Gamma)
					best_var = v;
				else if(pscore[v]+(step-time_stamp[v])/Gamma < pscore[best_var]+(step-time_stamp[best_var])/Gamma)
					continue;
				else if(time_stamp[v]<time_stamp[best_var])
					best_var = v;
			}
		}
		
		return best_var;
	}
	
	/*SD (significant decreasing) mode, the level with aspiration*/
	best_var = 0;
	for(i=0; i<unsatvar_stack_fill_pointer; ++i)
	{
		if(score[unsatvar_stack[i]]>sigscore) 
		{
			best_var = unsatvar_stack[i];
			break;
		}
	}

	for(++i; i<unsatvar_stack_fill_pointer; ++i)
	{
		v=unsatvar_stack[i];
		if(score[v]>score[best_var]) best_var = v;
		else if(score[v]==score[best_var])
		{
			if(pscore[v]+(step-time_stamp[v])/Gamma > pscore[best_var]+(step-time_stamp[best_var])/Gamma)
				best_var = v;
			else if(pscore[v]+(step-time_stamp[v])/Gamma < pscore[best_var]+(step-time_stamp[best_var])/Gamma)
				continue;
			else if(time_stamp[v]<time_stamp[best_var])
				best_var = v;
		}
	}
		
	if(best_var!=0) return best_var;
		
	/**Diversification Mode**/

	update_clause_weights();
	
	/*focused random walk*/
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	clause_c = clause_lit[c];
	best_var = clause_c[0].var_num;
	hscore_best_var = score[best_var]+pscore[best_var]/para_d+(step-time_stamp[best_var])/Beta;
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v=clause_c[k].var_num;
		hscore_v = score[v]+pscore[v]/para_d+(step-time_stamp[v])/Beta;
		if(hscore_v>hscore_best_var)
		{
			best_var = v;
			hscore_best_var = hscore_v;
		}
		else if(hscore_v<hscore_best_var)
			continue;
		else if(time_stamp[v]<time_stamp[best_var])
			best_var = v;
	}
	
	return best_var;
}

//pick a var to be flip
int pick_var_3SAT_DCCASat2014()
{
	int         i,k,c,v;
	int         best_var;
	lit*		clause_c;
	
	/**Greedy Mode**/
	/*CCD (configuration changed decreasing) mode, the level with configuation chekcing*/
	if(goodvar_stack_fill_pointer>0)
	{
	
		best_var = -1;
		for(i=0; i<goodvar_stack_fill_pointer; i++)
		{
			v = goodvar_stack[i];
			if(cscc[v]==1)
			{
				best_var = v;
				break;
			}
		}
		
		if(best_var!=-1)
		{
			for(i++; i<goodvar_stack_fill_pointer; i++)
			{
				v = goodvar_stack[i];
				if(cscc[v]==0)
					continue;
				if(score[v]>score[best_var]) best_var = v;
				else if(score[v]==score[best_var] && time_stamp[v]<time_stamp[best_var]) best_var = v;
			}
			return best_var;
		}
	
		best_var = goodvar_stack[0];
		
		for(i=1; i<goodvar_stack_fill_pointer; ++i)
		{
			v=goodvar_stack[i];
			if(score[v]>score[best_var]) best_var = v;
			else if(score[v]==score[best_var] && time_stamp[v]<time_stamp[best_var]) best_var = v;
		}
		
		return best_var;
	}
	
	/*SD (significant decreasing) mode, the level with aspiration*/
	best_var = 0;
	for(i=0; i<unsatvar_stack_fill_pointer; ++i)
	{
		if(score[unsatvar_stack[i]]>sigscore) 
		{
			best_var = unsatvar_stack[i];
			break;
		}
	}

	for(++i; i<unsatvar_stack_fill_pointer; ++i)
	{
		v=unsatvar_stack[i];
		if(score[v]>score[best_var]) best_var = v;
		else if(score[v]==score[best_var] && time_stamp[v]<time_stamp[best_var]) best_var = v;
	}
		
	if(best_var!=0) return best_var;
		
	/**Diversification Mode**/

	update_clause_weights();
	
	/*focused random walk*/
	c = unsat_stack[rand()%unsat_stack_fill_pointer];
	clause_c = clause_lit[c];
	best_var = clause_c[0].var_num;
	for(k=1; k<clause_lit_count[c]; ++k)
	{
		v=clause_c[k].var_num;
		if(time_stamp[v]<time_stamp[best_var]) best_var = v;
	}
	
	return best_var;
}


#endif

