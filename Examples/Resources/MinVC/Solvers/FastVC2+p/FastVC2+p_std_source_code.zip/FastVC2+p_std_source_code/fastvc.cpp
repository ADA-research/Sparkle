#include "fastvc.h"
#include "preprocess.h"
#include <signal.h>

string inst;
char *inst_c_ptr;
int seed;
int fix_vertices_size;

int try_step=100;


int edge_cand;

void handle_interrupt(int sig) 
{
	cout << "c" << endl;
	cout << "c caught signal... exiting" << endl;
	
	cout << "c vertex_cover: " << best_c_size + fix_vertices_size << " run_time: " << best_comp_time << " best_step: " << best_step << endl;
	
	cout << "c" <<endl;
	free_memory();
	exit(-1);
}

void setup_signal_handler() {
	signal(SIGTERM, handle_interrupt);
	signal(SIGINT, handle_interrupt);
	signal(SIGQUIT, handle_interrupt);
	//signal(SIGABRT, handle_interrupt);
	signal(SIGKILL, handle_interrupt);
}


void cover_LS(Preprocess &preprocess, double preprocess_time)
{
	int		remove_v, add_v;
	int		e,v1,v2;

	step = 1;

	while(1)
	{
		if (uncov_stack_fill_pointer == 0)//update best solution if needed
		{
			update_best_sol();
			
			cout << "c vertex_cover: " << best_c_size + preprocess.get_fix_vertices_size() << " run_time: " << best_comp_time + preprocess_time << " best_step: " << best_step << endl;
			
			if (best_c_size + preprocess.get_fix_vertices_size()==optimal_size) return;

			update_target_size();

			continue;
		}

		if(step%try_step==0) //check cutoff
		{
			times(&finish);
			double elap_time = (finish.tms_utime + finish.tms_stime - start_time)/sysconf(_SC_CLK_TCK);
			if(elap_time >= cutoff_time)return;
		}

		remove_v = choose_remove_v();
		//remove_dscore = dscore[remove_v];

		remove(remove_v);

		/*if (uncov_stack_fill_pointer < edge_cand)
		  {
		  e = uncov_stack[0];
		  v1 = edge[e].v1;
		  v2 = edge[e].v2;
		  if(dscore[v1]>dscore[v2] || (dscore[v1]==dscore[v2] && time_stamp[v1]<time_stamp[v2]) )
		  add_v=v1;
		  else add_v=v2;

		  for (i=1; i < uncov_stack_fill_pointer; ++i)
		  {
		  e = uncov_stack[i];
		  v1 = edge[e].v1;
		  v2 = edge[e].v2;

		  if(dscore[v1]>dscore[add_v] || (dscore[v1]==dscore[add_v] && time_stamp[v1]<time_stamp[add_v]) )
		  add_v=v1;
		  if(dscore[v2]>dscore[add_v] || (dscore[v2]==dscore[add_v] && time_stamp[v2]<time_stamp[add_v]) )
		  add_v=v2;
		  }

		  }

		  else{
		  e = uncov_stack[rand()%uncov_stack_fill_pointer];
		  v1 = edge[e].v1;
		  v2 = edge[e].v2;
		  if(dscore[v1]>dscore[v2] || (dscore[v1]==dscore[v2] && time_stamp[v1]<time_stamp[v2]) )
		  add_v=v1;
		  else add_v=v2;

		  for (i=1; i < edge_cand; ++i)
		  {
		  e = uncov_stack[rand()%uncov_stack_fill_pointer];
		  v1 = edge[e].v1;
		  v2 = edge[e].v2;

		  if(dscore[v1]>dscore[add_v] || (dscore[v1]==dscore[add_v] && time_stamp[v1]<time_stamp[add_v]) )
		  add_v=v1;
		  if(dscore[v2]>dscore[add_v] || (dscore[v2]==dscore[add_v] && time_stamp[v2]<time_stamp[add_v]) )
		  add_v=v2;
		  }

		  }*/

		e = uncov_stack[rand()%uncov_stack_fill_pointer];
		v1 = edge[e].v1;
		v2 = edge[e].v2;


		if(dscore[v1]>dscore[v2] || (dscore[v1]==dscore[v2] && time_stamp[v1]<time_stamp[v2]) )
			add_v=v1;
		else add_v=v2;


		add(add_v);


		int index = index_in_remove_cand[remove_v];
		index_in_remove_cand[remove_v] = 0;

		remove_cand[index] = add_v;
		index_in_remove_cand[add_v] = index;

		time_stamp[add_v]=time_stamp[remove_v]=step;

		//tabu_remove = add_v;

		//update_edge_weight();

		step++;
	}

}


bool parse_arguments(int argc, char *argv[])
{
	int i;
	bool flag_inst = false;
	bool flag_seed = false;
	bool flag_opt = false;
	bool flag_cutoff_time = false;
	bool flag_cand_count = false;
	
	for(i=1; i<argc; i++)
	{
		if(strcmp(argv[i], "-inst") == 0)
		{
			i++;
			if(i>=argc) return false;
			inst = argv[i];
			inst_c_ptr = argv[i];
			flag_inst = true;
			continue;
		}
		else if(strcmp(argv[i], "-seed") == 0)
		{
			i++;
			if(i>=argc) return false;
			sscanf(argv[i], "%d", &seed);
			flag_seed = true;
			continue;
		}
		else if(strcmp(argv[i], "-opt") == 0)
		{
			i++;
			if(i>=argc) return false;
			sscanf(argv[i], "%d", &optimal_size);
			flag_opt = true;
			continue;
		}
		else if(strcmp(argv[i], "-cutoff_time") == 0)
		{
			i++;
			if(i>=argc) return false;
			sscanf(argv[i], "%lf", &cutoff_time);
			flag_cutoff_time = true;
			continue;
		}
		else if(strcmp(argv[i], "-cand_count") == 0)
		{
			i++;
			if(i>=argc) return false;
			sscanf(argv[i], "%d", &cand_count);
			flag_cand_count = true;
			continue;
		}
		else return false;
	}
	
	if(!flag_opt)
	{
		optimal_size = 0;
	}
	
	if(!flag_cand_count)
	{
		cand_count = 50;
	}
	
	if(flag_inst && flag_seed && flag_cutoff_time) return true;
	else return false;
}



int main(int argc, char* argv[])
{
	/*
	if (argc != 5) {
		cout << "usage: " << endl;
		return 0;
	}
	int seed,i;
	*/
	
	setup_signal_handler();
	
	if(!parse_arguments(argc, argv))
	{
		cout << "c" << endl;
		cout << "c Arguments Error!" << endl;
		cout << "c Usage: " << argv[0] << " -inst <inst> -seed <seed> -cutoff_time <cutoff_time> [-opt <optimal_size>] [-cand_count <cand_count>]]" << endl;
		cout << "c" << endl;
		return -1;
	}
	
	cout << "c" << endl;
	cout << "c FastVC2+p" << endl;
	cout << "c inst = " << inst << endl;
	cout << "c seed = " << seed << endl;
	cout << "c target_optimal_size = " << optimal_size << endl;
	cout << "c cutoff_time = " << cutoff_time << endl;
	cout << "c cand_count = " << cand_count << endl;
	cout << "c" << endl;
	
	//cout<<"c This is NuMVC, a local search solver for the Minimum Vertex Cover (and also Maximum Independent Set) problem."<<endl;

	//preprocessing
	//Preprocess preprocess(argv[1]);
	Preprocess preprocess(inst_c_ptr);
	times(&start);
	preprocess.dominate_simplify_v();
	start_time = start.tms_utime + start.tms_stime;
	times(&finish);
	double preprocess_time = double(finish.tms_utime + finish.tms_stime - start_time)/sysconf(_SC_CLK_TCK);
	cout << "c preprocess time = " << preprocess_time << endl;
	cout << "c fix_vertice size = " << preprocess.get_fix_vertices_size() << endl;
	fix_vertices_size = preprocess.get_fix_vertices_size();

	//simplified_graph is empty
	if(build_instance(preprocess.get_adjacency_matrix()) != 1){
		times(&start);
		start_time = start.tms_utime + start.tms_stime;
		if (preprocess.verify((long*) 0, (long*) 0)) {
#ifndef NDEBUG
			cout << "c vc: ";
			preprocess.out_solution((long*) 0, (long*) 0);
#endif
			cout << "c initialize solution = " << preprocess.get_fix_vertices_size() << endl;
			cout << "c initialize time = " << 0 << endl;
			cout << "c Best found vertex cover size = " << preprocess.get_fix_vertices_size() << endl;
			cout << "c searchSteps = " << best_step << endl;
			cout << "c solvetime(includes preprocess time) = " << best_comp_time + preprocess_time << endl;
			cout << "c vertex_cover: " << preprocess.get_fix_vertices_size() << " run_time: " << best_comp_time + preprocess_time << " best_step: " << 0 << endl;
		}
		else {
			cout<<"the solution is wrong."<<endl;
		}
		return 0;
	}
	
//	preprocess.shrink_memory();

	times(&start);
	start_time = start.tms_utime + start.tms_stime;
	
	/*
	optimal_size=0;
	i=2;
	sscanf(argv[i++],"%d",&cand_count);
	//sscanf(argv[i++],"%d",&edge_cand);
	sscanf(argv[i++],"%d",&seed);
	sscanf(argv[i++],"%lf",&cutoff_time);
	*/
	cutoff_time -= preprocess_time;


	srand(seed);

	//cout<<seed<<' ';
	//		cout<<argv[1]<<' ';


	// init_sol();
	init_sol_merge();
	cout << "c initialize solution = " << best_c_size + preprocess.get_fix_vertices_size() << endl; 
	cout << "c initialize time = " << best_comp_time << endl;
	cout << "c vertex_cover: " << best_c_size + preprocess.get_fix_vertices_size() << " run_time: " << best_comp_time + preprocess_time << " best_step: " << 0 << endl;

	if(best_c_size + preprocess.get_fix_vertices_size() > optimal_size ) 
	{
	//cout<<"c Start local search..."<<endl;
	cover_LS(preprocess, preprocess_time);
	}

	//check solution
	long *solution = new long[best_c_size];
	for (long i = 1, j = 0; i <= v_num; ++i) {
		if (best_v_in_c[i] == 1) {
			solution[j++] = i;
		}
	}
	if (preprocess.verify(solution, solution + best_c_size)) {
#ifndef NDEBUG
		cout << "c vc: ";
		preprocess.out_solution(solution, solution + best_c_size);
#endif
		cout << "c Best found vertex cover size = " << best_c_size + preprocess.get_fix_vertices_size() << endl;
		cout << "c searchSteps = " << best_step << endl;
		cout << "c solvetime(includes preprocess time) = " << best_comp_time + preprocess_time << endl;
		cout << "c vertex_cover: " << best_c_size + preprocess.get_fix_vertices_size() << " run_time: " << best_comp_time + preprocess_time << " best_step: " << best_step << endl;
	}

	//		if(check_solution()==1)
	//		{
	//			cout<<"c Best found vertex cover size = "<<best_c_size<<endl;
	//			print_solution();
	//			cout<<"c searchSteps = "<<best_step<<endl;
	//			cout<<"c solveTime = "<<best_comp_time<<endl;

	//			cout<<best_c_size<<' '<<best_comp_time<<' '<<best_step<<endl;
	//		}
	else
	{
		cout<<"the solution is wrong."<<endl;
		//print_solution();
	}
	delete []solution;

	free_memory();

	return 0;
}
