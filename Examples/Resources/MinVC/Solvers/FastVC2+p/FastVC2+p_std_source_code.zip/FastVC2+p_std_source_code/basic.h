/************************************************
 ** This is a local search solver for Minimum Vertex Cover.                                                       
 ************************************************/


/************************************************
 ** Date:	2015.2.2  
 ** FastVC
 ** Author: Shaowei Cai, caisw@ios.ac.cn   
 **		   Key Laboratory of Computer Science,
 **		   Institute of Software, Chinese Academy of Sciences, 
 **		   Beijing, China                                                                        
 ************************************************/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <unistd.h>
#include <string.h>
#include <vector>

#include <sys/times.h>
#include <cmath>

using namespace std;


#define pop(stack) stack[--stack ## _fill_pointer]
#define push(item, stack) stack[stack ## _fill_pointer++] = item

tms start, finish;
int start_time;

struct Edge{
	int v1;
	int v2;
};

/*parameters of algorithm*/
long long	max_steps;			//step limit
double		cutoff_time;			//time limit
long long	step;
int			optimal_size;			//terminate the algorithm before step limit if it finds a vertex cover of optimal_size

/*parameters of the instance*/
int		v_num;//|V|: 1...v
int		e_num;//|E|: 0...e-1

/*structures about edge*/
Edge *edge;

/*structures about vertex*/
int*	dscore;						//dscore of v
long long*	time_stamp;


//from vertex to it's edges and neighbors
int**	v_edges;		//edges related to v, v_edges[i][k] means vertex v_i's k_th edge
int**	v_adj;			//v_adj[v_i][k] = v_j(actually, that is v_i's k_th neighbor)
int*	v_degree;		//amount of edges (neighbors) related to v


/* structures about solution */
//current candidate solution
int		c_size;						//cardinality of C
bool*	v_in_c;						//a flag indicates whether a vertex is in C
int		tmp_c_size;						//cardinality of C
bool*	tmp_v_in_c;						//a flag indicates whether a vertex is in C
int*	remove_cand;				//remove candidates, an array consists of only vertices in C, not including tabu_remove
int*	index_in_remove_cand;
int		remove_cand_size;

//best solution found
int		best_c_size;
bool*	best_v_in_c;				//a flag indicates whether a vertex is in best solution
double  best_comp_time;
long    best_step;


//uncovered edge stack
int*	uncov_stack;				//store the uncov edge number
int		uncov_stack_fill_pointer;
int*	index_in_uncov_stack;		//which position is an edge in the uncov_stack


//CC and taboo
//int 	conf_change[MAXV];
//int		tabu_remove=0;

string init_method;
