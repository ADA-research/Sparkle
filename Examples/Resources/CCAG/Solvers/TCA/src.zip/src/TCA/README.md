TCA: A tool for generating CA for constrained combinatorial interaction testing
==============================================================================

compile
-------

make

usage
-----

./TCA \<model file\> [\<constraint file\>] \<cutoff time\> \<seed\>

results
------

the raw results used in the paper of ASE2015 are in the "result" director

the excel tables are in "result/excel"
