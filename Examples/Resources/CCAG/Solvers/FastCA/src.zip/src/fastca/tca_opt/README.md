TCA
==============================================================================

compile
-------

make

usage
-----

./TCA \<model file\> [\<constraint file\>] \<cutoff time\> \<seed\>
