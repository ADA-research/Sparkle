FastCA
==============================================================================

compile
-------

make

usage
-----

./FastCA \<model file\> [\<constraint file\>] \<cutoff time\> \<seed\>
