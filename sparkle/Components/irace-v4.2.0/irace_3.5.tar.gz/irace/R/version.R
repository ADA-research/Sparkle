#' irace.version
#'
#' A character string containing the version of `irace`.
#' @export
irace.version <- '3.5.6863679'
