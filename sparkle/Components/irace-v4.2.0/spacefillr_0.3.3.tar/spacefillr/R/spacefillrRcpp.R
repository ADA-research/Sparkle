#' @useDynLib spacefillr, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
