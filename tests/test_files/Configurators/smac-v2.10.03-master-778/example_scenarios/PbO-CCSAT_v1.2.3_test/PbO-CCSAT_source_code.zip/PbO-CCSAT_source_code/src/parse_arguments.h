#ifndef _PARSE_ARGUMENTS_H
#define _PARSE_ARGUMENTS_H

#include "basis.h"

bool parse_arguments(int argc, char **argv);

#endif
