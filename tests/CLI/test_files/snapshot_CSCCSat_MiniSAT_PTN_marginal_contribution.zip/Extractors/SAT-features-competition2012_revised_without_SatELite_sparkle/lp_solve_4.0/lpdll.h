#define LPSOLVEDLL

#include "lpkit.h"
