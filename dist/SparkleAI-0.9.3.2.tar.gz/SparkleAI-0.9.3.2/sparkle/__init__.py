"""Init file for sparkle."""
import sparkle.about as about
__version__ = about.version
