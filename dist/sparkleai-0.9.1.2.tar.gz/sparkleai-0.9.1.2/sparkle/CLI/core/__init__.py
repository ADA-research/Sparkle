"""Init of CLI core module."""
