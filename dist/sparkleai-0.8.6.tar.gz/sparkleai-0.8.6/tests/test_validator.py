"""Tests for Validator Class."""


def test_validator_constructor() -> None:
    """Test Validator initialization."""
    # TODO: Write test
    pass


def test_validate() -> None:
    """Test Validator validate method."""
    # NOTE: Make sure runrunner calls are mocked to prevent slurm job submission
    # TODO: Write test
    pass


def test_retrieve_raw_results() -> None:
    """Test Validator retrieve_raw_results method."""
    # TODO: Write test
    pass


def test_get_validation_results() -> None:
    """Test Validator get_validation_results method."""
    # TODO: Write test
    pass


def test_append_entry_to_csv() -> None:
    """Test Validator append_entry_to_csv method."""
    # TODO: Write test
    pass
