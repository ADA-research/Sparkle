"""Test ablation scenario class."""


def test_ablation_scenario_constructor() -> None:
    """Test for ablation scenario constructor."""
    # TODO: Write test
    pass


def test_create_configuration_file() -> None:
    """Test for method create_configuration_file."""
    # TODO: Write test, check that written contents match with expected value
    pass


def test_create_instance_file() -> None:
    """Test for method create_instance_file."""
    # TODO: Write test for with training set
    # TODO: Write test for with test set
    pass


def test_check_for_ablation() -> None:
    """Test for method check_for_ablation."""
    # TODO: Write test for when correct file exists
    # TODO: Write test for when file does not exist
    # TODO: Write test for when file is corrupted
    pass


def test_read_ablation_table() -> None:
    """Test for reading an ablation table from file."""
    # TODO: Write test for correct file

    # TODO: Write test for not existant file

    # TODO: Write test for partially corrupted file
    pass


def test_submit_ablation() -> None:
    """Test for method submit ablation."""
    # NOTE: RunRunner calls must be mocked to avoid slurm job submission
    # TODO: Write test
    pass
