"""Test files for Extractor class."""


def test_extractor_constructor() -> None:
    """Test for constructor."""
    # TODO: Write test
    pass


def test_features() -> None:
    """Test for property features."""
    # TODO: Write test
    pass


def test_feature_groups() -> None:
    """Test for property feature_groups."""
    # TODO: Write test
    pass


def test_output_dimension() -> None:
    """Test for property output_dimension."""
    # TODO: Write test
    pass


def test_groupwise_computation() -> None:
    """Test for property groupwise_computation."""
    # TODO: Write test
    pass


def test_build_cmd() -> None:
    """Test for method build_cmd."""
    # TODO: Write test
    pass


def test_run() -> None:
    """Test for method run."""
    # TODO: Write test
    pass


def test_get_feature_vector() -> None:
    """Test for method get_feature_vector."""
    # TODO: Write test
    pass
