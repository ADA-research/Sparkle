"""Init for CLI help package."""
