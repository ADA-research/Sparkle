"""Initialising for the output module."""
