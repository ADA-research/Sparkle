"""This package provides solver support for Sparkle."""
