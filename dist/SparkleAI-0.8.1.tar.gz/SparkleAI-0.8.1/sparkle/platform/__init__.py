"""This package provides platform support for Sparkle."""
