"""This package provides platform support for Sparkle."""
from sparkle.platform.settings_objects import Settings, SettingState
