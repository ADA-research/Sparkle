Contact
=======

AutoFolio v2 is developed by the `ML4AAD Group of the University of Freiburg <http://www.ml4aad.org/>`_.

If you found a bug, please report to https://github.com/mlindauer/AutoFolio

