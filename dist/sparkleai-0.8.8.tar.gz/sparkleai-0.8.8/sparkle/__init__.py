"""Init file for sparkle."""
import sparkle.about as about
