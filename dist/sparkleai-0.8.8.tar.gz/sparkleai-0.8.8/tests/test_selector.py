"""Test files for Selector class."""


def test_selector_constructor() -> None:
    """Test for method constructor."""
    # TODO: Write test
    pass


def test_build_construction_cmd() -> None:
    """Test for method creation of the selector construction command."""
    # TODO: Write test, verify that output string is correct
    # Test with various runtime/wc time values and SparkleObjectives
    pass


def test_construct() -> None:
    """Test for method construct."""
    # NOTE: Make sure to mock RunRunner calls to avoid slurm job submission
    # TODO: Write test
    pass


def test_build_cmd() -> None:
    """Test for method build_cmd."""
    # TODO: Write test
    pass


def test_run() -> None:
    """Test for method run."""
    # NOTE: RunRunner calls must be mocked to avoid slurm job submission
    # TODO: Write test
    pass


def test_process_predict_schedule_output() -> None:
    """Test for method process_predict_schedule_output."""
    # TODO: Write test
    pass
