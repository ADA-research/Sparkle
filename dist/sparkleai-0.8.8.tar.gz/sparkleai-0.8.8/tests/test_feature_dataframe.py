"""Tests for feature dataframe class."""


def test_feature_dataframe_constructor() -> None:
    """Test feature dataframe constructor."""
    # TODO: write test
    pass


def test_add_extractor() -> None:
    """Test for method add_extractor."""
    # TODO: Write test
    pass


def test_add_instances() -> None:
    """Test for method add_instances."""
    # TODO: Write test
    pass


def test_remove_extractor() -> None:
    """Test for method remove_extractor."""
    # TODO: Write test
    pass


def test_remove_instances() -> None:
    """Test for method remove_instances."""
    # TODO: Write test
    pass


def test_get_feature_groups() -> None:
    """Test for method get_feature_groups."""
    # TODO: Write test
    pass


def get_value() -> None:
    """Test for method get_value."""
    # TODO: Write test
    pass


def set_value() -> None:
    """Test for method set_value."""
    # TODO: Write test
    pass


def test_has_missing_vectors() -> None:
    """Test for method has_missing_vectors."""
    # TODO: Write test for completely filled FDF
    # TODO: Write test for:
    #  - atleast one missing value per instance for all extractors
    #  - One feature group being compeletely missing
    #  - One instance being completely missing
    pass


def test_get_remaining_jobs() -> None:
    """Test for method get_remaining_jobs."""
    # TODO: Write test
    pass


def test_get_instance() -> None:
    """Test for method get_instance."""
    # TODO: Write test
    pass


def test_impute_missing_values() -> None:
    """Test for method impute_missing_values."""
    # TODO: Write test for one missing value (Can be calculated)
    # TODO: Write test for one missing feature in every instance
    pass


def test_has_missing_values() -> None:
    """Test for method has_missing_values."""
    # TODO: Write test
    pass


def test_reset_dataframe() -> None:
    """Test for method reset_dataframe."""
    # TODO: Write test
    pass


def test_sort() -> None:
    """Test for method sort."""
    # TODO: Write test
    pass


def test_instances() -> None:
    """Test instances property."""
    # TODO: Write test
    pass


def test_extractors() -> None:
    """Test for property extractors."""
    # TODO: Write test
    pass


def test_save_csv() -> None:
    """Test for method save_csv."""
    # TODO: Write test
    pass


def test_to_autofolio() -> None:
    """Test for method to_autofolio."""
    # TODO: Write test
    pass
