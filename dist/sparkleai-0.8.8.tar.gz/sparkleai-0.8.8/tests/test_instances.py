"""Test class for the InstanceSet class."""


def test_resolve_instance_set() -> None:
    """Test for resolving the correct instance set subclass."""
    # TODO: Write test for MultiFileInstanceSet
    # TODO: Write test for IterableFileInstanceSet
    # TODO: Write test for FileInstanceSet
    pass


def test_multi_file_instance_set() -> None:
    """Test for MultiFileInstanceSet properties."""
    # TODO: Write test
    pass


def test_iterable_file_instance_set() -> None:
    """Test for IterableFileInstanceSet properties."""
    # TODO: Write test
    pass


def test_file_instance_set() -> None:
    """Test for FileInstanceSet properties."""
    # TODO: Write test
    pass
