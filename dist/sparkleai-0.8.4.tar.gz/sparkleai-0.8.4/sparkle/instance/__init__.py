"""This package provides instance support for Sparkle."""
from sparkle.instance.instances import InstanceSet
