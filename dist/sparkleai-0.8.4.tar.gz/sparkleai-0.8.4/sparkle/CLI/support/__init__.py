"""Init for CLI support package."""
