"""This package provides types for Sparkle applications."""
