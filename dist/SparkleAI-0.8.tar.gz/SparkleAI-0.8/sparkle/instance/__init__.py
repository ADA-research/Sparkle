"""This package provides instance support for Sparkle."""
