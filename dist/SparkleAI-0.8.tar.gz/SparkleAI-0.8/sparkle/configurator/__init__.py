"""This package provides configurator support for Sparkle."""
