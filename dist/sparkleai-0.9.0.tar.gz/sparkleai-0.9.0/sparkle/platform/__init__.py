"""This package provides platform support for Sparkle."""
from sparkle.platform.cli_types import CommandName, COMMAND_DEPENDENCIES
from sparkle.platform.settings_objects import Settings, SettingState
