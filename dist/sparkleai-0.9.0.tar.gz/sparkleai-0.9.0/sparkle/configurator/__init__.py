"""This package provides configurator support for Sparkle."""
# Imports impossible due to circularity
# from sparkle.configurator.configurator import Configurator, ConfigurationScenario
